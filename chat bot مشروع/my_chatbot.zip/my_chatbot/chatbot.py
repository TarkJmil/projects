from nltk.chat.util import Chat, reflections

pairs = [
    ["مرحبا|هلا|السلام", ["مرحبا! كيف يمكنني مساعدتك؟"]],
    ["كيف حالك؟", ["أنا بخير، شكرًا!"]],
    ["(.*) اسمك؟", ["أنا بوت الدعم الفني!"]],
]

chatbot = Chat(pairs, reflections)

def get_response(user_input):
    return chatbot.respond(user_input)